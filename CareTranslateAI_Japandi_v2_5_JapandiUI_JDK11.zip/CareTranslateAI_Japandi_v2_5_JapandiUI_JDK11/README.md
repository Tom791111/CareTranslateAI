# CareTranslateAI Japandi v2.5 UI Refresh - JDK 11

本版以使用者指定的 v2.5 為基礎，只更新 JFrame 視覺風格與主要流程畫面，不改動原本核心功能。

## 更新重點
- JFrame 介面更新為 Japandi / Warm Minimal 風格
- 首頁改為卡片式 Dashboard + 兩欄功能入口
- 取代傳統 emoji，使用 Java2D 線性 icon badge
- 登入、角色選擇、Splash、SOS 頁面重新排版
- 保留 v2.5：後台、SOS 顯示電話、走失定位、警局通報、MySQL、MVC + DAO

## 執行
```bash
java -jar dist/CareTranslateAI_Japandi_v2_5_JapandiUI_JDK11.jar
```

## Eclipse
請刪除舊專案後重新 Import：
File → Import → Existing Maven Projects → 選擇此資料夾。
